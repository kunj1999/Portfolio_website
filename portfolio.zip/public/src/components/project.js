import React from "react";
import { SectionHeading } from "./common";
import {Chrono} from "react-chrono";

const projects=[
    {
        title: "May 2021",
        cardTitle: "Portfolio Website",
        cardSubtitle: "May 2021 - Current",
        cardDetailedText: "This is an improved version of the portfolio website I developed last year. Developed using ReactJS, Bootstrap, NodeJS and Jquery."
    },
    {
        title: "Apr 2021",
        cardTitle: "E-Tutor",
        cardSubtitle: "Feb 2021 - Apr 2021",
        cardDetailedText: "Website that would allows students to interact with tutors around the globe. The wesite utilized bootstrap for dynamic design and JQuery for interactivity. It was developed using HTML, CSS, JavaScript and PHP."
    },
    {
        title: "Dec 2020",
        cardTitle: "Secure Drop",
        cardSubtitle: "Oct 2020 - Dec 2020",
        cardDetailedText: "Python application to securily transfer files over nerwork. Utilized SHA-256 and PGP encryption scheme to ensure confidentiality and data integrity"
    },
    {
        title: "Dec 2020",
        cardTitle: "Personal Website",
        cardSubtitle: "Sep 2020 - Dec 2020",
        cardDetailedText: "Portfolio website to showcase my skills and achievements. It also contains links to other tasks that were carried during the projects. This was my first exposure to web development. Mainly developed using HTML, CSS and JQuery"
    },
]

export default class Projects extends React.Component {
    render(){
        return (
            <div className="project-wrap">
                <SectionHeading heading="Projects"/>
                <Chrono items={projects} mode="VERTICAL"/>
            </div>
        )
    }
}