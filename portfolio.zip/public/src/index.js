import About from "./components/about";
import Experience from "./components/experience";
import Landing from "./components/landing";
import Navbar from "./components/navbar";
import React from "react";
import ReactDOM from 'react-dom';
import Projects from "./components/project";

ReactDOM.render(
    <>
        <Navbar />
        <Landing />
        <About />
        <Experience />
        <Projects />
    </>, 
    document.getElementById("App"));